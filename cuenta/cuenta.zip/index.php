<!DOCTYPE HTML>
<?php require_once('../code/connect.php');
error_reporting(0);

$registro= $_GET['registro'];
$correo= $_GET['correo'];

require_once("../sesion.class.php");
    
    $sesion = new sesion();
    $usuario = $sesion->get("usuario");

     $consulta = mysqli_query($connect, "SELECT * FROM usuario WHERE correo='$usuario'")
    or die ("Error al traer los datos");

     while ($row = mysqli_fetch_array($consulta)){

        $nombre=$row['nombre'];
        $id=$row['id'];
        $documento=$row['documento'];
        $cedula=$row['cedula'];
        $telefono=$row['telefono'];
        $estado=$row['estado'];
        $ciudad=$row['ciudad'];
        $direccion=$row['direccion'];
        $fecha_registro=$row['fecha_registro'];


     }

?>


<!DOCTYPE HTML>
<!--
	Twenty by HTML5 UP
	html5up.net | @ajlkn
	Free for personal and commercial use under the CCA 3.0 license (html5up.net/license)
-->
<?php
    require_once("../sesion.class.php");
    
    $sesion = new sesion();
    $usuario = $sesion->get("usuario");

    if ($usuario!='') {
    	$iniciada=1;
    }else{$iniciada=0;}

     if ($usuario=='') {
       header("Location: ../login.php?mensaje=error_compra"); 
    }
?>
<html>
	<head>
		<title>VENEZAR - Perfil</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<!--[if lte IE 8]><script src="../assets/js/ie/html5shiv.js"></script><![endif]-->
		<link rel="stylesheet" href="../assets/css/main.css" />
		<!--[if lte IE 8]><link rel="stylesheet" href="assets/css/ie8.css" /><![endif]-->
		<script src='https://www.google.com/recaptcha/api.js'></script>
		<script type="text/javascript" src="../jquery-1.3.2.js"></script>
		<link rel="stylesheet" type="text/css" href="../assets/css/menu-cuenta.css">


		<!-- Include scripts -->
	<script type="text/javascript" src="http://code.jquery.com/jquery.min.js"></script> 
	<script type="text/javascript" src="js/responsivemultimenu.js"></script>

	<!-- Include styles -->
	<link rel="stylesheet" href="css/responsivemultimenu.css" type="text/css"/>

	<!-- Include media queries -->
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no"/>
	</head>
	<body>
		<div id="page-wrapper">

			<!-- Header -->
				<header id="header">
					<h1 id="logo"><a href="../index.php">VENEZAR</a></h1>
					<div id="tasa" style="padding:5px; width:40%;  position:relative; left:50%; top:-50px; margin-left:-35%; margin-bottom:20px;">
						<center>
							<p style="font-size:14px;"> <strong><?php date_default_timezone_set('America/La_Paz'); echo date("d/m/Y - H:i"); ?></strong><br></p>
							<p style="margin-top:-30px; border-top:1px solid white;">
							Venta por Bitcoin en Bolivares = <strong>999.999 Bs</strong><br> 
							Compra por Bitcoin en Bolivares = <strong>899.999 Bs</strong> </p>

						</center>
					</div>
					<nav id="nav">
						<ul>
							<li class="current"><a href="../index.php">INICIO</a></li>
							<li class="submenu">
								<a href="#">MENÚ</a>
								<ul>
									<?php if ($iniciada==1){ ?>
							<?php }else{ ?>
							<li><a href="../registro.php">Registrate</a></li>
							<?php } ?>
									<li><a href="../compra-bitcoins.php">Comprar BitCoins</a></li>
									<li><a href="#">Vender BitCoins</a></li>
									<li><a href="#">Ver Tutorial</a></li>
									<?php if ($iniciada==1){ ?>
							<li><a href="../cerrarsesion.php" class="button">Cerrar Sesión</a> </li>
							<?php }else{ ?>
							
							<?php } ?>
									
								</ul>
							</li>
							<?php if ($iniciada==1){ ?>
							<li><a href="../cuenta/" class="button special"><?php echo $usuario; ?></a> </li>
							<?php }else{ ?>
							<li><a href="../login.php" class="button special">Iniciar Sesión</a> </li>
							<?php } ?>
						</ul>
					</nav>
				</header>
			<!-- Main -->
				<section id="main" class="container 75%" style="background-color:white; padding:20px; margin-top:120px;">


					<header>
						<h2>Bienvenid@, <span style="color:green;"><?php echo $nombre; ?></span>.</h2>
						<h3>Número de Cliente: <span style="color:green;"> VZ-<?php echo $id; ?></span>.</h3>
						<p>Comienza a referir amigos y gana <span style="font-weight:bolder;">0,005 BITCOINS</span> por cada amigo que logre completar su ingreso Nivel 1 en <span style="font-weight:bolder;">ZARFUND</span>.</p>
						<div id="cuenta">
						

						</div>
					</header>

					<div>
		<div class="rmm style">
			<ul>
				<li>
					<a href="#">Mi cuenta</a>
					<ul>
						<li>
							<a href="#">Mis Compras</a>
						</li>
						<li>
							<a href="#">Mis Ventas</a>
						</li>

						<li>
							<a href="#.php">Modificar mi información</a>
						</li>
											</ul>
				</li>
				<li>
					<a href="#">Comprar BitCoins</a>
				</li>
				<li>
					<a href="#">Vender BitCoins</a>
				</li>
				<li>
					<a href="#">Referir Amigos</a>
				</li>
			</ul>
		</div>
	</div>


	<section style="margin-top:40px;" class="box special features">
						<div class="features-row">
							<section style="position:relative; width:100%;">
								<h1 style="font-size:24px; color:black; font-weight:bolder; text-decoration:underline;">CUADRO DE NOTICIAS</h1>
								<br>
									<p style="font-size:18px; color:black;">Hola, <span style="color:green;"> <?php echo $nombre; ?></span>. 
									<br> No hay noticias nuevas. </p>


							</section>

						</div>
					</section>

					<div class="row">
						<div class="6u 12u(narrower)">

							<section class="box special">
								<span class="image featured"><img src="../images/pic02.jpg" alt="" /></span>
								<h3>Blog</h3>
								<p>Entra a nuestro blog y podrás discutir sobre cualquier duda que tengas.</p>
								<ul class="actions">
									<li><a href="#" class="button alt">Ir al blog</a></li>
								</ul>
							</section>

						</div>
						<div class="6u 12u(narrower)">

							<section class="box special">
								<span class="image featured"><img src="../images/pic03.jpg" alt="" /></span>
								<h3>Compartir</h3>
								<p>Comparte nuestra página con tus amigos en Facebook.</p>
								<ul class="actions">
									<li><a href="#" class="button alt">Compartir en FACEBOOK</a></li>
								</ul>
							</section>

						</div>
					</div>

				</section>
	</section>

					
			<!-- Footer -->
				<footer id="footer">
					<ul class="icons">
						<li><a href="#" class="icon fa-twitter"><span class="label">Twitter</span></a></li>
						<li><a href="#" class="icon fa-facebook"><span class="label">Facebook</span></a></li>
						<li><a href="#" class="icon fa-instagram"><span class="label">Instagram</span></a></li>
					</ul>
					<ul class="copyright">
						<li>&copy; VENEZAR.COM.VE (Todos los derechos reservados) - 2016</li>
					</ul>
				</footer>

		</div>

<!-- Scripts -->
			<script src="../assets/js/jquery.min.js"></script>
			<script src="../assets/js/jquery.dropotron.min.js"></script>
			<script src="../assets/js/jquery.scrolly.min.js"></script>
			<script src="../assets/js/jquery.scrollgress.min.js"></script>
			<script src="../assets/js/skel.min.js"></script>
			<script src="../assets/js/util.js"></script>
			<!--[if lte IE 8]><script src="../assets/js/ie/respond.min.js"></script><![endif]-->
			<script src="../assets/js/main.js"></script>

	</body>
</html>